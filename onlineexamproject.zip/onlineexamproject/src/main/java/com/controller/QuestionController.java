package com.controller;



import java.net.http.HttpRequest;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.entity.Answer;
import com.entity.Questions;

@Controller
public class QuestionController {
	
@RequestMapping("saveresponse")
public void saveResponse(Answer answer,HttpServletRequest request)
{

	System.out.println(answer);
	
	HttpSession httpsession=request.getSession();
	List<Questions> listofquestions=(List<Questions>) httpsession.getAttribute("allquestions");
	Questions question= listofquestions.get((int)httpsession.getAttribute("qno"));
	
	 String orignalAnswer=question.getAnswer();
	 answer.setOriginalAnswer(orignalAnswer);
	 System.out.println(orignalAnswer);
	
	HashMap<Integer,Answer> hashmap=(HashMap<Integer,Answer>) httpsession.getAttribute("submittedDetails");
	hashmap.put(answer.qno, answer);
	System.out.println(httpsession.getAttribute("submittedDetails"));
	
	
	
}
@RequestMapping("endexam")
public ModelAndView endExam(HttpServletRequest request) {
	HttpSession httpsession=request.getSession();
// we took hashmap here beacuse if user change the submitted answer hashmap help to update it.
	HashMap<Integer,Answer> hashmap=(HashMap<Integer,Answer>) httpsession.getAttribute("submittedDetails");
	ModelAndView  modelandview=new ModelAndView ();
	modelandview.setViewName("score");

	if(hashmap!=null) {
Collection<Answer> collection=hashmap.values();
for (Answer answer : collection) {
if(answer.originalAnswer.equals(answer.submittedAnswer)) {
	httpsession.setAttribute("score",(int)httpsession.getAttribute("score")+1);
}
}
	//modelandview.addObject("score",httpsession.getAttribute("score"));
	
httpsession.setAttribute("allanswer",collection);
	
	httpsession.removeAttribute("submittedDetails");
	}
	return modelandview;
	
}
//this code for moving to next page and if we are last page and clcik on next it will show question are over message
@RequestMapping("next")
public ModelAndView  next(HttpServletRequest request) {
	ModelAndView  modelandview=new ModelAndView ();
	HttpSession httpsession=request.getSession();
	
	//listquestionsize is 3 then increse till 1 index at 2 dont increse
	List<Questions> listofquestions=(List<Questions>)httpsession.getAttribute("allquestions");
if((int)httpsession.getAttribute("qno")<=listofquestions.size()-2) {
	httpsession.setAttribute("qno",(int)httpsession.getAttribute("qno")+1);
	
	Questions question=listofquestions.get((int)httpsession.getAttribute("qno"));
	int qno=question.getQno();
	//code to retrive previous answer
		HashMap<Integer,Answer> hashmap=(HashMap<Integer,Answer>) httpsession.getAttribute("submittedDetails");

		
		Answer answer=hashmap.get(qno);
		String previousAnswer="";
		if(answer!=null) {
			previousAnswer=answer.submittedAnswer;
		}
		
		modelandview.addObject("previousAnswer", previousAnswer);
	modelandview.setViewName("questions");
	modelandview.addObject("question", question);
}
else {
modelandview.setViewName("questions");

modelandview.addObject("message","questions are over");
modelandview.addObject("question",listofquestions.get(listofquestions.size()-1));//3-2=1 
}
	return modelandview;
	
}
@RequestMapping("previous")
public ModelAndView  previous(HttpServletRequest request) {
	ModelAndView  modelandview=new ModelAndView ();
	HttpSession httpsession=request.getSession();
	
	List<Questions> listofquestions=(List<Questions>)httpsession.getAttribute("allquestions");
//012=3
//012
	//2>=1 //1>=1 //0>=1 false
if((int)httpsession.getAttribute("qno")>0) { //if index 1 then go previous
	httpsession.setAttribute("qno",(int)httpsession.getAttribute("qno")-1);
	
	Questions question=listofquestions.get((int)httpsession.getAttribute("qno"));
	//code to retrive previous answer
	HashMap<Integer,Answer> hashmap=(HashMap<Integer,Answer>) httpsession.getAttribute("submittedDetails");

	int qno=question.getQno();
	Answer answer=hashmap.get(qno);
	String previousAnswer="";
	if(answer!=null) {
		previousAnswer=answer.submittedAnswer;
	}
	
	modelandview.setViewName("questions");
	modelandview.addObject("question", question);
	modelandview.addObject("previousAnswer", previousAnswer);
}
else {
modelandview.setViewName("questions");
modelandview.addObject("message","questions are over");
modelandview.addObject("question",listofquestions.get(0));

//modelandview.addObject("message","questions are over"); //
}
	return modelandview;
	
}

}
